<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer">
                        <h2>Footer</h2>
                    </div>
                </div>                
            </div>
        </div>




</div>
</body>
</html>