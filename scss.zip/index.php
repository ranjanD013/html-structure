
<?php include 'header.php'; ?>


<section>
<div class="container">
            <div class="row">
            <div class="col-lg-3">
                    <div class="leftContent">
                        <h2>Left Content</h2>
                    </div>
                </div>
                <div class="col-lg-6 px-0">
                    <div class="midContent">
                        <h2>Main Content</h2>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="RightContent">
                        <h2>Right Content</h2>
                    </div>
                </div>
            </div>
        </div>
</section>








<?php include 'footer.php'; ?>